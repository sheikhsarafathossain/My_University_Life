<div class="top-bar">
  <h3 class="text-center pt-2 mb-0">Welcome to PoshuPakhi</h3>
  <p class="text-center pb-2 mb-0 pt-0">Everything for Your Pets & Birds.</p>
</div>

